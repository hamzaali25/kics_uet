<?php
if(isset($_GET['submit'])){
    $name = $_GET['name'];
    $email = $_GET['email'];
    if($name==='' or $email===''){
        echo "Please Complete Your Form!";
    }
    else {
        echo $name;
        echo "<br>";
        echo $email;
    }
}
else {
    echo "You are not authorized!";
}
    

?>